import { fetchLiveAmazonProduct } from "../services/amazon_service.js";

// Pre-configure Gemini API Key for instant live vision
const DEFAULT_GEMINI_KEY = "AQ.Ab8RN6IQE3yEL-bhBlLLnC6Nx5ySk_tUxFaYWosQGXu7MIljDA";
chrome.storage.local.get(["geminiApiKey"], (res) => {
  if (!res || !res.geminiApiKey) {
    chrome.storage.local.set({ geminiApiKey: DEFAULT_GEMINI_KEY });
  }
});

// Enable side panel to open on action click and trigger scan
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error("Error setting panel behavior:", error));

// When extension icon is clicked in toolbar, trigger scan on active tab
chrome.action.onClicked.addListener((tab) => {
  if (tab && tab.id) {
    chrome.sidePanel.open({ tabId: tab.id }).catch(() => {});
    chrome.tabs.sendMessage(tab.id, { action: "TRIGGER_SCAN" }).catch(() => {});
  }
});

let latestScanResults = null;
let liveRequests = [];
let cartItems = [];

async function enrichProductsWithRealAmazon(results) {
  if (!results) return results;

  // Enrich Exact Matches
  if (results.exactMatches && results.exactMatches.length > 0) {
    for (const item of results.exactMatches) {
      const query = item.title || item.detectionLabel;
      const live = await fetchLiveAmazonProduct(query);
      if (live) {
        item.asin = live.asin;
        item.image = live.image;
        item.title = live.title;
        item.price = live.price;
      }
    }
  }

  // Enrich Look-Alikes
  if (results.lookAlikes && results.lookAlikes.length > 0) {
    for (const item of results.lookAlikes) {
      const query = item.title || item.detectionLabel;
      const live = await fetchLiveAmazonProduct(query);
      if (live) {
        item.asin = live.asin;
        item.image = live.image;
        item.title = live.title;
        item.price = live.price;
      }
    }
  }

  return results;
}

// Listen for incoming messages from content scripts and side panel
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "OPEN_SIDEPANEL") {
    if (sender.tab && sender.tab.id) {
      chrome.sidePanel.open({ tabId: sender.tab.id }).catch((err) => {
        console.warn("Could not open side panel:", err);
      });
    }
    sendResponse({ status: "ok" });
    return true;
  }

  if (message.action === "CAPTURE_VISIBLE_TAB") {
    chrome.tabs.captureVisibleTab(null, { format: "jpeg", quality: 85 }, (dataUrl) => {
      if (chrome.runtime.lastError || !dataUrl) {
        sendResponse({ error: chrome.runtime.lastError?.message || "Failed to capture tab" });
      } else {
        sendResponse({ dataUrl });
      }
    });
    return true;
  }

  if (message.action === "ANALYZE_CROPPED_IMAGE") {
    const { croppedImage, apiKey, streamContext } = message;
    analyzeCroppedObjectWithAI(croppedImage, apiKey, streamContext)
      .then(async (results) => {
        const enriched = await enrichProductsWithRealAmazon(results);
        latestScanResults = {
          streamType: `🎯 Cropped: ${streamContext?.title || 'Live Stream'}`,
          croppedThumbnail: croppedImage,
          items: enriched,
          capturedAt: new Date().toLocaleTimeString()
        };
        chrome.storage.local.set({ latestScanResults });
        chrome.runtime.sendMessage({ action: "SCAN_RESULTS_UPDATED", data: latestScanResults }).catch(() => {});
        sendResponse({ success: true, data: latestScanResults });
      })
      .catch((err) => {
        console.error("Crop AI analysis error:", err);
        sendResponse({ success: false, error: err.message });
      });
    return true;
  }

  if (message.action === "ANALYZE_WITH_AI") {
    const { imageBase64, apiKey, streamContext } = message;
    analyzeWithGeminiVision(imageBase64, apiKey, streamContext)
      .then(async (results) => {
        const enriched = await enrichProductsWithRealAmazon(results);
        latestScanResults = {
          streamType: streamContext?.title || "Live Stream",
          items: enriched,
          capturedAt: new Date().toLocaleTimeString()
        };
        chrome.storage.local.set({ latestScanResults });
        chrome.runtime.sendMessage({ action: "SCAN_RESULTS_UPDATED", data: latestScanResults }).catch(() => {});
        sendResponse({ success: true, data: latestScanResults });
      })
      .catch((err) => {
        sendResponse({ success: false, error: err.message });
      });
    return true;
  }



  if (message.action === "SAVE_SCAN_RESULTS") {
    latestScanResults = message.data;
    chrome.storage.local.set({ latestScanResults });
    // Broadcast update to open side panel if active
    chrome.runtime.sendMessage({
      action: "SCAN_RESULTS_UPDATED",
      data: latestScanResults
    }).catch(() => {});
    sendResponse({ status: "saved" });
    return true;
  }

  if (message.action === "GET_LATEST_SCAN") {
    if (latestScanResults) {
      sendResponse({ data: latestScanResults });
    } else {
      chrome.storage.local.get(["latestScanResults"], (result) => {
        latestScanResults = result.latestScanResults || null;
        sendResponse({ data: latestScanResults });
      });
    }
    return true;
  }

  if (message.action === "ADD_TO_CART") {
    const product = message.product;
    if (product) {
      const existing = cartItems.find((item) => item.asin === product.asin);
      if (existing) {
        existing.quantity = (existing.quantity || 1) + 1;
      } else {
        cartItems.push({ ...product, quantity: 1, addedAt: Date.now() });
      }
      chrome.storage.local.set({ cartItems });
      chrome.runtime.sendMessage({ action: "CART_UPDATED", cartItems }).catch(() => {});
    }
    sendResponse({ status: "added", cartItems });
    return true;
  }

  if (message.action === "GET_CART") {
    chrome.storage.local.get(["cartItems"], (result) => {
      cartItems = result.cartItems || [];
      sendResponse({ cartItems });
    });
    return true;
  }

  if (message.action === "SUBMIT_REQUEST") {
    const requestItem = message.requestItem;
    liveRequests.push({
      ...requestItem,
      submittedAt: Date.now(),
      status: "Pinged Creator ⚡"
    });
    chrome.storage.local.set({ liveRequests });
    chrome.runtime.sendMessage({ action: "REQUESTS_UPDATED", liveRequests }).catch(() => {});
    sendResponse({ status: "submitted", liveRequests });
    return true;
  }

  if (message.action === "GET_REQUESTS") {
    chrome.storage.local.get(["liveRequests"], (result) => {
      liveRequests = result.liveRequests || [];
      sendResponse({ liveRequests });
    });
    return true;
  }
});

/**
 * Direct Gemini 2.0 / 1.5 Multi-Modal Vision API integration
 */
async function analyzeWithGeminiVision(imageBase64, apiKey, streamContext) {
  // Strip header if present
  const cleanBase64 = imageBase64.replace(/^data:image\/(png|jpeg|jpg);base64,/, "");

  const prompt = `You are StreamSnap AI, a visual shopping engine for live streams.
Analyze this video screenshot from stream titled: "${streamContext?.title || 'Live Stream'}".
Identify visible consumer products (microphones, headphones, clothing, cups/bottles, lights, desk pads, electronics, etc.).

Return a clean JSON object with this exact structure:
{
  "exactMatches": [
    {
      "asin": "B0002E4Z8M",
      "title": "Exact Full Product Name",
      "brand": "Brand",
      "price": 99.99,
      "image": "https://m.media-amazon.com/images/I/71P4q+HqKQL._AC_SL1500_.jpg",
      "confidence": 0.95,
      "detectionLabel": "Short Label",
      "matchReason": "Why it matched",
      "boundingBox": {"ymin": 20, "xmin": 30, "ymax": 60, "xmax": 70}
    }
  ],
  "lookAlikes": [
    {
      "asin": "B09KND9W8Z",
      "title": "Similar Amazon Alternative Product",
      "price": 39.99,
      "image": "https://m.media-amazon.com/images/I/71p0W+3XfUL._AC_UX679_.jpg",
      "similarityScore": 90,
      "detectionLabel": "Short Label",
      "matchReason": "Visual similarity explanation",
      "boundingBox": {"ymin": 40, "xmin": 20, "ymax": 85, "xmax": 60}
    }
  ],
  "unidentifiedRequests": [
    {
      "id": "req_1",
      "label": "Item Description",
      "category": "Apparel/Decor",
      "reason": "Why brand is obscured",
      "requestCount": 5,
      "boundingBox": {"ymin": 50, "xmin": 50, "ymax": 70, "xmax": 70}
    }
  ]
}`;

  let response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [
        {
          parts: [
            { text: prompt },
            {
              inline_data: {
                mime_type: "image/jpeg",
                data: cleanBase64
              }
            }
          ]
        }
      ],
      generationConfig: {
        response_mime_type: "application/json"
      }
    })
  });

  if (!response.ok) {
    // Fallback to gemini-flash-latest
    response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=${apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              { text: prompt },
              {
                inline_data: {
                  mime_type: "image/jpeg",
                  data: cleanBase64
                }
              }
            ]
          }
        ],
        generationConfig: {
          response_mime_type: "application/json"
        }
      })
    });
  }

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Gemini API Error: ${errorText}`);
  }

  const json = await response.json();
  const textContent = json.candidates?.[0]?.content?.parts?.[0]?.text || "{}";
  const clean = textContent.replace(/^```json\n?/, '').replace(/\n?```$/, '').trim();
  return JSON.parse(clean);
}


/**
 * Direct Pinpoint Multi-Modal Vision Analysis on a user-selected Crop
 */
async function analyzeCroppedObjectWithAI(croppedBase64, apiKey, streamContext) {
  if (!croppedBase64) {
    throw new Error("No cropped image provided");
  }

  const cleanBase64 = croppedBase64.replace(/^data:image\/(png|jpeg|jpg);base64,/, "");

  const prompt = `You are StreamSnap AI, a visual search and shopping engine.
The user clicked and CROPPED this specific object on a live stream titled: "${streamContext?.title || 'Live Stream'}".
Analyze ONLY this specific cropped item in the image (e.g. superhero suit, mask, mic, bottle, hoodie, logo, shoes, gadget).

Return a clean JSON object with this exact structure:
{
  "exactMatches": [
    {
      "asin": "B0002E4Z8M",
      "title": "Exact Full Product Name on Amazon",
      "brand": "Brand Name",
      "price": 39.99,
      "confidence": 0.96,
      "detectionLabel": "Cropped Item",
      "matchReason": "Exact visual match for the selected crop"
    }
  ],
  "lookAlikes": [
    {
      "asin": "B09KND9W8Z",
      "title": "Top Rated Alternative on Amazon",
      "price": 29.99,
      "similarityScore": 92,
      "detectionLabel": "Alternative Item",
      "matchReason": "Style and form match for the cropped selection"
    }
  ],
  "unidentifiedRequests": []
}`;

  let response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [
        {
          parts: [
            { text: prompt },
            {
              inline_data: {
                mime_type: "image/jpeg",
                data: cleanBase64
              }
            }
          ]
        }
      ],
      generationConfig: {
        response_mime_type: "application/json"
      }
    })
  });

  if (!response.ok) {
    response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=${apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              { text: prompt },
              {
                inline_data: {
                  mime_type: "image/jpeg",
                  data: cleanBase64
                }
              }
            ]
          }
        ],
        generationConfig: {
          response_mime_type: "application/json"
        }
      })
    });
  }

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Gemini API Error: ${errorText}`);
  }

  const json = await response.json();
  const textContent = json.candidates?.[0]?.content?.parts?.[0]?.text || "{}";
  const clean = textContent.replace(/^```json\n?/, '').replace(/\n?```$/, '').trim();
  return JSON.parse(clean);
}


