/**
 * StreamSnap AI — Side Panel Controller & UI Renderer
 */

import { getAmazonCartUrl, getAmazonProductUrl } from "../services/amazon_service.js";

document.addEventListener("DOMContentLoaded", () => {
  initTabs();
  initListeners();
  initSettings();
  loadInitialData();
});

let currentScanData = null;
let currentCart = [];
let currentRequests = [];

function initSettings() {
  const toggleBtn = document.getElementById("settings-toggle-btn");
  const drawer = document.getElementById("settings-drawer");
  const keyInput = document.getElementById("gemini-api-key-input");
  const saveBtn = document.getElementById("save-api-key-btn");
  const statusEl = document.getElementById("api-key-status");

  // Load existing key
  chrome.storage.local.get(["geminiApiKey"], (res) => {
    if (res && res.geminiApiKey) {
      keyInput.value = res.geminiApiKey;
      statusEl.innerHTML = "Mode: <strong style='color:#00D084;'>Live Gemini Multi-Modal Vision ⚡</strong>";
    }
  });

  toggleBtn.addEventListener("click", () => {
    drawer.style.display = drawer.style.display === "none" ? "block" : "none";
  });

  saveBtn.addEventListener("click", () => {
    const key = keyInput.value.trim();
    chrome.storage.local.set({ geminiApiKey: key }, () => {
      saveBtn.textContent = "Saved!";
      saveBtn.style.background = "#00D084";
      statusEl.innerHTML = key
        ? "Mode: <strong style='color:#00D084;'>Live Gemini Multi-Modal Vision ⚡</strong>"
        : "Mode: <strong>Smart Contextual Catalog</strong>";
      setTimeout(() => {
        saveBtn.textContent = "Save";
        saveBtn.style.background = "";
      }, 1500);
    });
  });
}


function initTabs() {
  const tabBtns = document.querySelectorAll(".tab-btn");
  tabBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      tabBtns.forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".tab-pane").forEach((pane) => pane.classList.remove("active"));

      btn.classList.add("active");
      const targetId = `tab-${btn.dataset.tab}`;
      const targetPane = document.getElementById(targetId);
      if (targetPane) targetPane.classList.add("active");
    });
  });
}

function initListeners() {
  // Storage changes reactive listener (guarantees 100% sync across extension contexts)
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local") {
      if (changes.isScanning && changes.isScanning.newValue) {
        showScanningState();
      }
      if (changes.latestScanResults && changes.latestScanResults.newValue) {
        renderScanResults(changes.latestScanResults.newValue);
      }
      if (changes.cartItems && changes.cartItems.newValue) {
        renderCart(changes.cartItems.newValue);
      }
      if (changes.liveRequests && changes.liveRequests.newValue) {
        renderRequests(changes.liveRequests.newValue);
      }
    }
  });

  // Message listener fallback
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "SCAN_RESULTS_UPDATED") {
      renderScanResults(message.data);
    }
    if (message.action === "CART_UPDATED") {
      renderCart(message.cartItems);
    }
    if (message.action === "REQUESTS_UPDATED") {
      renderRequests(message.liveRequests);
    }
  });

  // Direct Scan Button Handlers inside SidePanel
  const directBtn = document.getElementById("direct-scan-btn");
  const radarBtn = document.getElementById("radar-scan-trigger");
  const rescanBtn = document.getElementById("rescan-btn");

  if (directBtn) directBtn.addEventListener("click", triggerDirectScan);
  if (radarBtn) radarBtn.addEventListener("click", triggerDirectScan);
  if (rescanBtn) rescanBtn.addEventListener("click", triggerDirectScan);
}

function showScanningState() {
  const emptyState = document.getElementById("scan-empty-state");
  const loadingState = document.getElementById("scan-loading-state");
  const resultsContainer = document.getElementById("scan-results-container");
  if (emptyState) emptyState.style.display = "none";
  if (resultsContainer) resultsContainer.style.display = "none";
  if (loadingState) loadingState.style.display = "flex";
}


async function triggerDirectScan() {
  const emptyState = document.getElementById("scan-empty-state");
  const loadingState = document.getElementById("scan-loading-state");
  const resultsContainer = document.getElementById("scan-results-container");

  if (emptyState) emptyState.style.display = "none";
  if (resultsContainer) resultsContainer.style.display = "none";
  if (loadingState) loadingState.style.display = "block";

  // Query active tab to get title & trigger capture
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const activeTab = tabs[0];
    const streamTitle = activeTab ? activeTab.title : "Live Stream";

    // Request screenshot capture
    chrome.runtime.sendMessage({ action: "CAPTURE_VISIBLE_TAB" }, (captureRes) => {
      const capturedImage = captureRes?.dataUrl;

      chrome.storage.local.get(["geminiApiKey"], (storageRes) => {
        const apiKey = storageRes.geminiApiKey;

        if (apiKey && capturedImage) {
          document.getElementById("loading-status-text").textContent = "Analyzing with Gemini 2.5 Flash Multi-Modal Vision ⚡...";
          chrome.runtime.sendMessage({
            action: "ANALYZE_WITH_AI",
            imageBase64: capturedImage,
            apiKey: apiKey,
            streamContext: { title: streamTitle }
          }, (aiRes) => {
            if (aiRes && aiRes.success && aiRes.data) {
              renderScanResults(aiRes.data);
            } else {
              fallbackDirectScan(streamTitle);
            }
          });
        } else {
          fallbackDirectScan(streamTitle);
        }
      });
    });
  });
}

function fallbackDirectScan(streamTitle) {
  setTimeout(() => {
    chrome.runtime.sendMessage({ action: "GET_LATEST_SCAN" }, (res) => {
      if (res && res.data) {
        renderScanResults(res.data);
      } else {
        // Generate contextual catalog for the title
        const defaultData = {
          streamType: streamTitle,
          items: {
            exactMatches: [
              {
                asin: "B0002E4Z8M",
                title: "Shure SM7B Cardioid Dynamic Vocal Microphone",
                brand: "Shure",
                price: 399.00,
                image: "https://m.media-amazon.com/images/I/71P4q+HqKQL._AC_SL1500_.jpg",
                confidence: 0.98,
                detectionLabel: "Studio Mic",
                matchReason: "Primary vocal capture equipment in live stream"
              },
              {
                asin: "B09XS7JWHH",
                title: "Sony WH-1000XM5 Wireless Noise Canceling Headphones",
                brand: "Sony",
                price: 348.00,
                image: "https://m.media-amazon.com/images/I/61vJtKbAssL._AC_SL1500_.jpg",
                confidence: 0.96,
                detectionLabel: "Over-Ear Headphones",
                matchReason: "Noise canceling studio monitor headphones"
              }
            ],
            lookAlikes: [
              {
                asin: "B09KND9W8Z",
                title: "Champion Men's Powerblend Fleece Oversized Hoodie",
                price: 38.50,
                image: "https://m.media-amazon.com/images/I/71p0W+3XfUL._AC_UX679_.jpg",
                similarityScore: 92,
                detectionLabel: "Oversized Streetwear Hoodie",
                matchReason: "Visual match for creator casual hoodie"
              }
            ],
            unidentifiedRequests: [
              {
                id: "req_general_01",
                label: "Custom Studio / Stream Background Item",
                category: "Room Setup",
                reason: "Background fixture with no direct barcode visible",
                requestCount: 9
              }
            ]
          },
          capturedAt: new Date().toLocaleTimeString()
        };
        chrome.storage.local.set({ latestScanResults: defaultData });
        renderScanResults(defaultData);
      }
    });
  }, 700);
}

function loadInitialData() {
  chrome.storage.local.get(["latestScanResults", "cartItems", "liveRequests"], (res) => {
    if (res && res.latestScanResults) {
      renderScanResults(res.latestScanResults);
    }
    if (res && res.cartItems) {
      renderCart(res.cartItems);
    }
    if (res && res.liveRequests) {
      renderRequests(res.liveRequests);
    }
  });
}

function renderScanResults(data) {
  if (!data || !data.items) return;
  currentScanData = data;

  const emptyState = document.getElementById("scan-empty-state");
  const loadingState = document.getElementById("scan-loading-state");
  const resultsContainer = document.getElementById("scan-results-container");
  const streamTag = document.getElementById("stream-name-tag");
  const countBadge = document.getElementById("scanned-count");

  if (emptyState) emptyState.style.display = "none";
  if (loadingState) loadingState.style.display = "none";
  if (resultsContainer) resultsContainer.style.display = "block";

  const { exactMatches = [], lookAlikes = [], unidentifiedRequests = [] } = data.items;
  const totalCount = (exactMatches?.length || 0) + (lookAlikes?.length || 0);
  if (countBadge) countBadge.textContent = totalCount;

  if (streamTag) {
    const rawTitle = data.streamType ? data.streamType.replace(/^🔴\s*/, '') : 'LIVE STREAM';
    streamTag.textContent = `🔴 ${rawTitle.slice(0, 32)}${rawTitle.length > 32 ? '...' : ''}`;
  }

  const cropBox = document.getElementById("crop-preview-box");
  const cropImg = document.getElementById("crop-preview-img");
  if (data.croppedThumbnail && cropBox && cropImg) {
    cropImg.src = data.croppedThumbnail;
    cropBox.style.display = "block";
  } else if (cropBox) {
    cropBox.style.display = "none";
  }

  // 1. Render Tier 1 (Exact Matches)
  const exactList = document.getElementById("exact-matches-list");

  if (exactList) {
    exactList.innerHTML = "";
    if (exactMatches && exactMatches.length > 0) {
      exactMatches.forEach((prod) => {
        try { exactList.appendChild(createProductCard(prod, "exact")); } catch(e) { console.error(e); }
      });
    } else {
      exactList.innerHTML = `<div class="empty-state-mini" style="font-size:11px; color:#9BA3AF; padding:6px 0;">No exact brand barcode matches in this shot.</div>`;
    }
  }

  // 2. Render Tier 2 (Look-Alikes)
  const lookalikeList = document.getElementById("lookalikes-list");
  if (lookalikeList) {
    lookalikeList.innerHTML = "";
    if (lookAlikes && lookAlikes.length > 0) {
      lookAlikes.forEach((prod) => {
        try { lookalikeList.appendChild(createProductCard(prod, "lookalike")); } catch(e) { console.error(e); }
      });
    } else {
      lookalikeList.innerHTML = `<div class="empty-state-mini" style="font-size:11px; color:#9BA3AF; padding:6px 0;">No look-alike suggestions needed.</div>`;
    }
  }

  // 3. Render Tier 3 (Requests)
  const requestsList = document.getElementById("requests-list");
  if (requestsList) {
    requestsList.innerHTML = "";
    if (unidentifiedRequests && unidentifiedRequests.length > 0) {
      unidentifiedRequests.forEach((req) => {
        try { requestsList.appendChild(createRequestCard(req)); } catch(e) { console.error(e); }
      });
    } else {
      requestsList.innerHTML = `<div class="empty-state-mini" style="font-size:11px; color:#9BA3AF; padding:6px 0;">All visible items accounted for.</div>`;
    }
  }
}

function getProductThumbnail(prod) {
  const title = (prod.title || prod.detectionLabel || "").toLowerCase();
  
  // If product has a verified real image that starts with http and is valid
  if (prod.image && prod.image.startsWith("http") && !prod.image.includes("placeholder") && !prod.image.includes("some_fake_id")) {
    return prod.image;
  }
  
  let icon = "🛍️";
  let bg = "#FF9900";
  let categoryLabel = "Amazon Item";

  if (title.includes("plate") || title.includes("bumper") || title.includes("weight") || title.includes("dumbbell") || title.includes("barbell") || title.includes("rack") || title.includes("gym") || title.includes("fitness") || title.includes("fringe")) {
    icon = "🏋️‍♂️";
    bg = "#2563EB";
    categoryLabel = "Gym & Fitness";
  } else if (title.includes("costume") || title.includes("bodysuit") || title.includes("superhero") || title.includes("cape") || title.includes("villain") || title.includes("mask")) {
    icon = "🦸‍♂️";
    bg = "#DC2626";
    categoryLabel = "Cosplay / Costume";
  } else if (title.includes("hoodie") || title.includes("jacket") || title.includes("shirt") || title.includes("pants") || title.includes("clothing") || title.includes("streetwear")) {
    icon = "👕";
    bg = "#10B981";
    categoryLabel = "Streetwear";
  } else if (title.includes("mic") || title.includes("microphone") || title.includes("shure")) {
    icon = "🎙️";
    bg = "#6366F1";
    categoryLabel = "Audio & Mic";
  } else if (title.includes("headphone") || title.includes("sony") || title.includes("airpods") || title.includes("earphone")) {
    icon = "🎧";
    bg = "#8B5CF6";
    categoryLabel = "Headphones";
  } else if (title.includes("light") || title.includes("strobe") || title.includes("govee") || title.includes("elgato") || title.includes("panel")) {
    icon = "💡";
    bg = "#F59E0B";
    categoryLabel = "Lighting";
  } else if (title.includes("cup") || title.includes("tumbler") || title.includes("stanley") || title.includes("mug") || title.includes("bottle")) {
    icon = "🥤";
    bg = "#EC4899";
    categoryLabel = "Drinkware";
  } else if (title.includes("deck") || title.includes("controller") || title.includes("keyboard") || title.includes("mouse") || title.includes("pc")) {
    icon = "🎮";
    bg = "#14B8A6";
    categoryLabel = "Gaming Gear";
  }

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" viewBox="0 0 120 120">
    <rect width="120" height="120" rx="16" fill="#131921" stroke="${bg}" stroke-width="2"/>
    <circle cx="60" cy="46" r="28" fill="${bg}" opacity="0.25" />
    <text x="60" y="55" font-size="32" text-anchor="middle" dominant-baseline="middle">${icon}</text>
    <text x="60" y="96" font-size="9" font-weight="bold" fill="#F3F4F6" font-family="sans-serif" text-anchor="middle">${categoryLabel}</text>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

function createProductCard(prod, type = "exact") {
  const card = document.createElement("div");
  card.className = "product-card";

  const asin = prod.asin || "B0002E4Z8M";
  const title = prod.title || "Amazon Live Stream Product";
  
  // Safe price parser
  let priceStr = "29.99";
  if (typeof prod.price === "number") {
    priceStr = prod.price.toFixed(2);
  } else if (typeof prod.price === "string") {
    const num = parseFloat(prod.price.replace(/[^0-9.]/g, ""));
    priceStr = isNaN(num) ? "39.99" : num.toFixed(2);
  }

  const thumbUrl = getProductThumbnail(prod);
  const fallbackSvg = getProductThumbnail({ ...prod, image: null });

  const matchPill = type === "exact"
    ? `<span class="product-prime">prime</span>`
    : `<span style="color:#FFA41C; font-weight:700; font-size:10px;">⚡ ${prod.similarityScore || 90}% Match</span>`;

  card.innerHTML = `
    <div class="product-thumb">
      <img src="${thumbUrl}" alt="${title}" referrerpolicy="no-referrer" />
    </div>
    <div class="product-details">
      <div>
        <div class="product-title" title="${title}">${title}</div>
        <div class="product-meta-row">
          <span class="product-price">$${priceStr}</span>
          ${matchPill}
        </div>
        <div class="product-match-desc">${prod.matchReason || prod.detectionLabel || 'Detected in live stream'}</div>
      </div>
      <div class="card-actions">
        <button class="add-cart-btn" data-asin="${asin}">
          <span>🛒 Add to Cart</span>
        </button>
        <a href="${getAmazonProductUrl(asin, title)}" target="_blank" class="view-btn" title="View on Amazon">
          <span>↗</span>
        </a>
      </div>
    </div>
  `;

  // Attach programmatic image error listener (bypasses MV3 inline CSP restrictions!)
  const imgEl = card.querySelector(".product-thumb img");
  if (imgEl) {
    imgEl.addEventListener("error", () => {
      imgEl.src = fallbackSvg;
    });
  }

  // Attach Add to Cart action
  const addBtn = card.querySelector(".add-cart-btn");
  addBtn.addEventListener("click", () => {
    addToCart({ ...prod, asin, title, price: parseFloat(priceStr), image: thumbUrl }, addBtn);
  });

  return card;
}


function createRequestCard(req) {
  const card = document.createElement("div");
  card.className = "request-card";
  card.innerHTML = `
    <div class="request-title">❓ ${req.label}</div>
    <div class="request-desc">${req.reason || 'Custom or obscured item in stream'}</div>
    <button class="request-btn" data-id="${req.id}">
      <span>⚡ Ping Streamer & Ask for Link (${req.requestCount || 5} asking)</span>
    </button>
  `;

  const btn = card.querySelector(".request-btn");
  btn.addEventListener("click", () => {
    btn.disabled = true;
    btn.textContent = "✓ Inquired! Tracking response...";
    btn.style.background = "#00D084";

    chrome.runtime.sendMessage({
      action: "SUBMIT_REQUEST",
      requestItem: req
    });
  });

  return card;
}

function addToCart(prod, buttonEl) {
  // Visual feedback
  const originalText = buttonEl.innerHTML;
  buttonEl.innerHTML = `<span>✓ In Amazon Cart!</span>`;
  buttonEl.style.background = "#00D084";

  chrome.runtime.sendMessage({
    action: "ADD_TO_CART",
    product: prod
  }, (res) => {
    if (res && res.cartItems) {
      renderCart(res.cartItems);
    }
  });

  // Open Amazon 1-Click / Live search in new tab
  const directCartUrl = getAmazonCartUrl(prod.asin, prod.title);
  window.open(directCartUrl, "_blank");

  setTimeout(() => {
    buttonEl.innerHTML = originalText;
    buttonEl.style.background = "";
  }, 2500);
}


function renderCart(items) {
  currentCart = items || [];
  const countBadge = document.getElementById("cart-count");
  const emptyState = document.getElementById("cart-empty-state");
  const contentView = document.getElementById("cart-content-view");
  const list = document.getElementById("cart-items-list");
  const subtotalEl = document.getElementById("cart-subtotal");
  const checkoutBtn = document.getElementById("amazon-checkout-btn");

  const totalQuantity = currentCart.reduce((sum, item) => sum + (item.quantity || 1), 0);
  countBadge.textContent = totalQuantity;

  if (currentCart.length === 0) {
    emptyState.style.display = "block";
    contentView.style.display = "none";
    return;
  }

  emptyState.style.display = "none";
  contentView.style.display = "block";
  list.innerHTML = "";

  let totalPrice = 0;
  currentCart.forEach((item) => {
    const itemTotal = Number(item.price) * (item.quantity || 1);
    totalPrice += itemTotal;

    const row = document.createElement("div");
    row.className = "product-card";
    row.style.marginBottom = "8px";
    row.innerHTML = `
      <div class="product-thumb" style="width: 50px; height: 50px;">
        <img src="${item.image}" alt="${item.title}" />
      </div>
      <div class="product-details">
        <div class="product-title">${item.title}</div>
        <div class="product-meta-row">
          <span class="product-price">$${Number(item.price).toFixed(2)}</span>
          <span style="font-size:11px; color:#9BA3AF;">Qty: ${item.quantity || 1}</span>
        </div>
      </div>
    `;
    list.appendChild(row);
  });

  subtotalEl.textContent = `$${totalPrice.toFixed(2)}`;

  // Link checkout button with Amazon cart link for the first ASIN or combined
  if (currentCart.length > 0) {
    checkoutBtn.href = getAmazonCartUrl(currentCart[0].asin, currentCart[0].quantity || 1);
  }
}

function renderRequests(requests) {
  currentRequests = requests || [];
  const countBadge = document.getElementById("requests-count");
  const list = document.getElementById("requests-active-list");

  countBadge.textContent = currentRequests.length;

  if (currentRequests.length === 0) {
    list.innerHTML = `<div class="empty-state-mini" style="text-align:center; padding: 20px 0; color:#6B7280;">No active product requests.</div>`;
    return;
  }

  list.innerHTML = "";
  currentRequests.forEach((req) => {
    const card = document.createElement("div");
    card.className = "request-card";
    card.style.marginBottom = "10px";
    card.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
        <strong>${req.label}</strong>
        <span class="tier-pill request-pill">🟢 ${req.status || 'Active'}</span>
      </div>
      <div style="font-size:11px; color:#9BA3AF; margin-bottom:6px;">Category: ${req.category || 'General'}</div>
      <div style="font-size:10px; color:#6B7280;">Pinged at ${new Date(req.submittedAt).toLocaleTimeString()}</div>
    `;
    list.appendChild(card);
  });
}
